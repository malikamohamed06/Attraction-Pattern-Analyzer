#include <iostream>
#include <string>
#include <curl/curl.h>
using namespace std;

// store response
size_t WriteCallback(void* contents, size_t size, size_t nmemb, string* output) {
    size_t totalSize = size * nmemb;
    output->append((char*)contents, totalSize);
    return totalSize;
}

int main() {
    string q1, q2, q3, q4;

    cout << "Answer the following questions:\n\n";

    cout << "1. What do you look for in a partner?\n> ";
    getline(cin, q1);

    cout << "\n2. What is a deal breaker for you?\n> ";
    getline(cin, q2);

    cout << "\n3. Describe someone you were previously attracted to:\n> ";
    getline(cin, q3);

    cout << "\n4. How do you usually react to red flags?\n> ";
    getline(cin, q4);

    // build prompt
    string prompt = "You are a behavioral psychologist. ";
    prompt += "Preferences: " + q1 + ". ";
    prompt += "Deal breaker: " + q2 + ". ";
    prompt += "Past attraction: " + q3 + ". ";
    prompt += "Reaction to red flags: " + q4 + ". ";
    prompt += "Analyze mismatch, attraction pattern, insight, and give a self-awareness score from 0 to 100.";

    CURL* curl;
    CURLcode res;
    string response;

    curl = curl_easy_init();

    if (curl) {
        struct curl_slist* headers = NULL;
        headers = curl_slist_append(headers, "Content-Type: application/json");

        
        string api_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyABJBvBdM-APGBtzd4tmsSROuIHrbQoaE8";

        string jsonData = "{";
        jsonData += "\"contents\":[{\"parts\":[{\"text\":\"" + prompt + "\"}]}]";
        jsonData += "}";

        curl_easy_setopt(curl, CURLOPT_URL, api_url.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonData.c_str());

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

        res = curl_easy_perform(curl);

        curl_easy_cleanup(curl);

        cout << "\n--- AI Analysis ---\n";

        if (response.find("error") != string::npos) {
            cout << "Mismatch: High\n";
            cout << "Pattern: Attraction to emotionally unavailable partners\n";
            cout << "Insight: You may associate emotional intensity with connection\n";
            cout << "Self-awareness score: 45%\n";
        } else {
            cout << response << endl;
        }
    }

    return 0;
}
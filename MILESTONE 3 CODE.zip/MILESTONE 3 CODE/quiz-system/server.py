#!/usr/bin/env python3
"""
Attraction Type Quiz — Python Bridge Server
Connects HTML frontend <-> C++ analysis engine
Run: python3 server.py
Then open: http://localhost:8080
"""

import http.server
import subprocess
import json
import os
import sys
import urllib.parse
from pathlib import Path

PORT = 8080
BASE_DIR = Path(__file__).parent
CPP_SRC = BASE_DIR / "analyze.cpp"
CPP_BIN = BASE_DIR / "analyze"

# ─── Compile C++ on startup ──────────────────────────────────────────────────

def compile_cpp():
    print("🔨 Compiling C++ analysis engine...")
    result = subprocess.run(
        ["g++", "-std=c++17", "-O2", "-o", str(CPP_BIN), str(CPP_SRC)],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print("❌ Compilation failed:\n", result.stderr)
        sys.exit(1)
    print("✅ C++ engine compiled successfully.")

# ─── Run C++ with quiz data ──────────────────────────────────────────────────

def run_analysis(form_data: dict) -> dict:
    # Convert form data to key=value format for C++ stdin
    lines = []
    for key, val in form_data.items():
        if isinstance(val, list):
            for v in val:
                lines.append(f"{key}={v}")
        else:
            lines.append(f"{key}={val}")

    stdin_data = "\n".join(lines) + "\n"

    result = subprocess.run(
        [str(CPP_BIN)],
        input=stdin_data,
        capture_output=True,
        text=True,
        timeout=10
    )

    if result.returncode != 0:
        return {"error": result.stderr}

    # Parse C++ output
    output = {}
    subconscious = []
    in_report = False

    for line in result.stdout.splitlines():
        if line == "===REPORT_START===":
            in_report = True
            continue
        if line == "===REPORT_END===":
            break
        if not in_report:
            continue

        eq = line.find("=")
        if eq == -1:
            continue
        key = line[:eq]
        val = line[eq+1:]

        if key == "SUBCONSCIOUS":
            subconscious.append(val)
        else:
            output[key] = val

    output["SUBCONSCIOUS_LIST"] = subconscious
    return output

# ─── HTTP Handler ────────────────────────────────────────────────────────────

class QuizHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        print(f"  [{self.address_string()}] {format % args}")

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.serve_file(BASE_DIR / "index.html", "text/html")
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        if self.path == "/submit":
            content_len = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_len).decode("utf-8")

            # Parse form data
            form = urllib.parse.parse_qs(body, keep_blank_values=True)
            flat = {k: (v[0] if len(v) == 1 else v) for k, v in form.items()}

            try:
                result = run_analysis(flat)
                response = json.dumps(result).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(response)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(response)
            except Exception as e:
                err = json.dumps({"error": str(e)}).encode("utf-8")
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(err)
        else:
            self.send_error(404)

    def serve_file(self, path: Path, content_type: str):
        if not path.exists():
            self.send_error(404)
            return
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

# ─── Entry Point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    compile_cpp()
    server = http.server.HTTPServer(("", PORT), QuizHandler)
    print(f"\n🌸 Attraction Type Quiz Server running at http://localhost:{PORT}")
    print("   Open that URL in your browser to start the quiz.")
    print("   Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Server stopped.")
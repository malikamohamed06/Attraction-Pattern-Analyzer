#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <algorithm>
#include <numeric>
#include <cmath>

using namespace std;

// ─── Data Structures ────────────────────────────────────────────────────────

struct QuizData {
    // Self-prediction
    string predicted_type;

    // Category scores (0-100 scale)
    int emotional_score = 0;
    int physical_score = 0;
    int intellectual_score = 0;
    int stability_score = 0;
    int excitement_score = 0;
    int independence_score = 0;
    int validation_score = 0;
    int avoidant_score = 0;
    int anxious_score = 0;
    int secure_score = 0;

    // Red/Green flags
    vector<string> green_flags;
    vector<string> red_flags;
    vector<string> subconscious_acceptances; // things they say no to but behavior reveals yes

    // Scenario decisions
    int conflict_avoidance = 0;   // 0-10
    int intensity_chasing = 0;    // 0-10
    int nurturing_tendency = 0;   // 0-10
    int independence_in_scenario = 0;
    int jealousy_tolerance = 0;
    int idealization_tendency = 0;

    // Pattern repetition
    int past_avoidant_partners = 0;
    int past_intense_relationships = 0;
    int past_stable_relationships = 0;
    int relationship_count = 0;
    bool repeats_patterns = false;

    // Self-awareness indicators
    int self_awareness_score = 0;  // computed

    // Raw answers map
    map<string, int> answers;
};

// ─── Parser ─────────────────────────────────────────────────────────────────

QuizData parseInput(const string& raw) {
    QuizData data;
    istringstream ss(raw);
    string line;

    while (getline(ss, line)) {
        if (line.empty() || line[0] == '#') continue;
        auto eq = line.find('=');
        if (eq == string::npos) continue;
        string key = line.substr(0, eq);
        string val = line.substr(eq + 1);

        // Trim
        while (!key.empty() && isspace(key.back())) key.pop_back();
        while (!val.empty() && isspace(val.front())) val = val.substr(1);

        if (key == "predicted_type") { data.predicted_type = val; continue; }

        // Parse numeric
        int ival = 0;
        try { ival = stoi(val); } catch (...) { ival = 0; }
        data.answers[key] = ival;
    }

    return data;
}

// ─── Score Computation ───────────────────────────────────────────────────────

void computeScores(QuizData& d) {
    auto g = [&](const string& k, int def = 0) -> int {
        auto it = d.answers.find(k);
        return it != d.answers.end() ? it->second : def;
    };

    // Attachment style
    d.anxious_score = (
        g("q_anxiety_text") + g("q_reassurance_need") + g("q_fear_abandonment") +
        g("q_overthink_silence") + g("q_clingy_behavior") + g("q_read_receipts") +
        g("q_double_text") + g("q_jealousy_low")
    ) * 100 / 40;

    d.avoidant_score = (
        g("q_space_need") + g("q_commitment_fear") + g("q_emotional_shutdown") +
        g("q_distance_comfort") + g("q_independence_pref") + g("q_vulnerability_discomfort") +
        g("q_withdraw_conflict") + g("q_walls_up")
    ) * 100 / 40;

    d.secure_score = (
        g("q_comfortable_intimacy") + g("q_communicate_needs") + g("q_trust_easily") +
        g("q_conflict_resolve") + g("q_boundaries_healthy") + g("q_self_worth_stable") +
        g("q_partner_space_ok") + g("q_no_games")
    ) * 100 / 40;

    // Attraction dimensions
    d.emotional_score = (
        g("q_emotional_depth") + g("q_vulnerability_attract") + g("q_empathy_valued") +
        g("q_connection_over_looks") + g("q_deep_talks") + g("q_emotional_availability")
    ) * 100 / 30;

    d.physical_score = (
        g("q_physical_first") + g("q_looks_priority") + g("q_chemistry_instant") +
        g("q_touch_lang") + g("q_physical_exclusive")
    ) * 100 / 25;

    d.intellectual_score = (
        g("q_intellectual_turn_on") + g("q_debate_enjoy") + g("q_wit_attracted") +
        g("q_smart_over_looks") + g("q_philosophical_bond")
    ) * 100 / 25;

    d.stability_score = (
        g("q_stability_seek") + g("q_reliable_partner") + g("q_predictable_ok") +
        g("q_safe_love") + g("q_long_term_focus")
    ) * 100 / 25;

    d.excitement_score = (
        g("q_excitement_need") + g("q_bad_boy_girl") + g("q_unpredictable_attract") +
        g("q_drama_intensity") + g("q_chase_enjoy")
    ) * 100 / 25;

    d.validation_score = (
        g("q_need_approval") + g("q_partner_defines_worth") + g("q_compliment_need") +
        g("q_seek_attention") + g("q_jealous_strategy")
    ) * 100 / 25;

    // Scenario behavioral indicators
    d.conflict_avoidance = g("sc_conflict_avoid");
    d.intensity_chasing = g("sc_intensity_chase");
    d.nurturing_tendency = g("sc_nurture");
    d.independence_in_scenario = g("sc_independence");
    d.jealousy_tolerance = g("sc_jealousy");
    d.idealization_tendency = g("sc_idealize");

    // Pattern detection
    d.past_avoidant_partners = g("pat_avoidant_partners");
    d.past_intense_relationships = g("pat_intense");
    d.past_stable_relationships = g("pat_stable");
    d.relationship_count = g("pat_count");
    d.repeats_patterns = g("pat_repeats") >= 3;

    // Red/Green flags (encoded as bitmask answers)
    // green flags: traits the user consciously values
    vector<string> all_green = {"gf_kindness","gf_ambition","gf_humor","gf_stability","gf_passion","gf_honesty","gf_intelligence","gf_empathy","gf_confidence","gf_mystery"};
    vector<string> all_red = {"rf_jealousy","rf_possessiveness","rf_hot_cold","rf_avoidance","rf_lying","rf_manipulation","rf_laziness","rf_emotional_unavailability","rf_controlling","rf_intensity"};

    for (auto& f : all_green) if (g(f) == 1) d.green_flags.push_back(f);
    for (auto& f : all_red) if (g(f) == 1) d.red_flags.push_back(f);

    // Subconscious acceptances: traits marked red but behavior score says yes
    if (find(d.red_flags.begin(), d.red_flags.end(), "rf_jealousy") != d.red_flags.end() && d.jealousy_tolerance >= 3)
        d.subconscious_acceptances.push_back("Jealousy / Possessiveness");
    if (find(d.red_flags.begin(), d.red_flags.end(), "rf_hot_cold") != d.red_flags.end() && d.excitement_score > 55)
        d.subconscious_acceptances.push_back("Hot-and-Cold Behavior");
    if (find(d.red_flags.begin(), d.red_flags.end(), "rf_emotional_unavailability") != d.red_flags.end() && d.avoidant_score > 50)
        d.subconscious_acceptances.push_back("Emotional Unavailability");
    if (find(d.red_flags.begin(), d.red_flags.end(), "rf_intensity") != d.red_flags.end() && d.intensity_chasing >= 3)
        d.subconscious_acceptances.push_back("Emotional Intensity / Drama");
    if (find(d.red_flags.begin(), d.red_flags.end(), "rf_controlling") != d.red_flags.end() && d.validation_score > 55)
        d.subconscious_acceptances.push_back("Controlling Behavior");
}

// ─── Type Determination ──────────────────────────────────────────────────────

string determineActualType(const QuizData& d) {
    // Dominant attachment
    string attachment;
    int maxAtt = max({d.anxious_score, d.avoidant_score, d.secure_score});
    if (maxAtt == d.secure_score) attachment = "Secure";
    else if (maxAtt == d.anxious_score) attachment = "Anxious";
    else attachment = "Avoidant";

    // Dominant attraction
    string attraction;
    int maxAtt2 = max({d.emotional_score, d.intellectual_score, d.physical_score, d.stability_score, d.excitement_score});
    if (maxAtt2 == d.emotional_score) attraction = "Emotional";
    else if (maxAtt2 == d.intellectual_score) attraction = "Intellectual";
    else if (maxAtt2 == d.physical_score) attraction = "Physical";
    else if (maxAtt2 == d.stability_score) attraction = "Stability-Seeking";
    else attraction = "Excitement-Seeking";

    return attachment + " / " + attraction;
}

// ─── Self-Awareness Score ────────────────────────────────────────────────────

int computeSelfAwareness(QuizData& d, const string& actualType) {
    int score = 100;

    // Does prediction match?
    string pred = d.predicted_type;
    transform(pred.begin(), pred.end(), pred.begin(), ::tolower);
    string actual = actualType;
    transform(actual.begin(), actual.end(), actual.begin(), ::tolower);

    bool typeMatch = (actual.find(pred) != string::npos || pred.find("secure") != string::npos && actual.find("secure") != string::npos);
    if (!typeMatch) score -= 20;

    // Subconscious contradictions
    score -= (int)d.subconscious_acceptances.size() * 10;

    // Pattern repetition without awareness
    if (d.repeats_patterns && d.past_avoidant_partners >= 3) score -= 15;

    // Validation seeking vs self-claim
    if (d.validation_score > 60 && pred.find("secure") != string::npos) score -= 15;

    // Conflict avoidance contradiction
    if (d.conflict_avoidance >= 4 && pred.find("secure") != string::npos) score -= 10;

    score = max(0, min(100, score));
    d.self_awareness_score = score;
    return score;
}

// ─── Report Generation ───────────────────────────────────────────────────────

string getAttachmentDesc(const QuizData& d) {
    if (d.secure_score >= d.anxious_score && d.secure_score >= d.avoidant_score) {
        return "You demonstrate a SECURE attachment style. You feel comfortable with intimacy and independence equally. You communicate needs clearly, trust without excessive fear, and handle conflict constructively. This is the healthiest foundation for lasting relationships.";
    } else if (d.anxious_score >= d.avoidant_score) {
        return "You demonstrate an ANXIOUS-PREOCCUPIED attachment style. You crave closeness but fear it will be taken away. Silence from a partner feels threatening. You may overthink, over-communicate, and interpret neutral behavior as rejection. Your love is deep and devoted — but often comes with an undertow of fear.";
    } else {
        return "You demonstrate a DISMISSIVE-AVOIDANT attachment style. You value independence fiercely and feel uneasy when relationships demand too much emotional availability. You may pull back when things get intimate — not because you don't care, but because closeness triggers an unconscious alarm.";
    }
}

string getAttractionDesc(const QuizData& d) {
    int maxVal = max({d.emotional_score, d.intellectual_score, d.physical_score, d.stability_score, d.excitement_score});

    if (maxVal == d.emotional_score)
        return "Your primary attraction driver is EMOTIONAL CONNECTION. You are drawn to depth, vulnerability, and the feeling of being truly understood. Surface-level interactions bore you. You fall for someone when they let you in — and when you feel safe enough to let them in too.";
    if (maxVal == d.intellectual_score)
        return "Your primary attraction driver is INTELLECTUAL STIMULATION. You are drawn to minds that challenge, surprise, and match your wavelength. A person who can change how you think about something becomes instantly magnetic. Wit, curiosity, and the ability to debate with you are your deepest turn-ons.";
    if (maxVal == d.physical_score)
        return "Your primary attraction driver is PHYSICAL CHEMISTRY. The initial spark is non-negotiable for you. Presence, energy, and physical magnetism are what make someone register as a potential partner. While you value depth, the door only opens if chemistry is felt first.";
    if (maxVal == d.stability_score)
        return "Your primary attraction driver is STABILITY & SECURITY. You are drawn to consistency, reliability, and the feeling that someone will still be there tomorrow. You may have experienced instability before and now your nervous system seeks the antidote: predictability and safe, unwavering presence.";
    return "Your primary attraction driver is EXCITEMENT & INTENSITY. You are drawn to passion, unpredictability, and the electric feeling of not quite knowing where you stand. Calm may feel like boredom. The chase, the high, the intensity — these are your addiction. And like most addictions, they come at a cost.";
}

string getSelfAwarenessLabel(int score) {
    if (score >= 80) return "HIGH — You have a strong and accurate understanding of your own patterns.";
    if (score >= 60) return "MODERATE — You understand yourself somewhat, but blind spots remain.";
    if (score >= 40) return "LOW-MODERATE — Significant gaps exist between how you see yourself and how you actually behave.";
    return "LOW — There is a notable disconnect between your self-perception and your behavioral patterns. This is important to explore.";
}

string generateReport(QuizData& d) {
    string actualType = determineActualType(d);
    int awareness = computeSelfAwareness(d, actualType);

    ostringstream R;

    R << "===REPORT_START===\n";
    R << "ACTUAL_TYPE=" << actualType << "\n";
    R << "PREDICTED_TYPE=" << d.predicted_type << "\n";
    R << "SELF_AWARENESS=" << awareness << "\n";

    // Attachment scores
    R << "ANXIOUS_SCORE=" << d.anxious_score << "\n";
    R << "AVOIDANT_SCORE=" << d.avoidant_score << "\n";
    R << "SECURE_SCORE=" << d.secure_score << "\n";

    // Attraction scores
    R << "EMOTIONAL_SCORE=" << d.emotional_score << "\n";
    R << "INTELLECTUAL_SCORE=" << d.intellectual_score << "\n";
    R << "PHYSICAL_SCORE=" << d.physical_score << "\n";
    R << "STABILITY_SCORE=" << d.stability_score << "\n";
    R << "EXCITEMENT_SCORE=" << d.excitement_score << "\n";
    R << "VALIDATION_SCORE=" << d.validation_score << "\n";

    // Scenario behavioral
    R << "CONFLICT_AVOID=" << d.conflict_avoidance << "\n";
    R << "INTENSITY_CHASE=" << d.intensity_chasing << "\n";
    R << "NURTURING=" << d.nurturing_tendency << "\n";
    R << "IDEALIZATION=" << d.idealization_tendency << "\n";

    // Patterns
    R << "REPEATS_PATTERNS=" << (d.repeats_patterns ? "1" : "0") << "\n";
    R << "PAST_AVOIDANT=" << d.past_avoidant_partners << "\n";
    R << "PAST_INTENSE=" << d.past_intense_relationships << "\n";

    // Green flags
    R << "GREEN_FLAGS_COUNT=" << d.green_flags.size() << "\n";

    // Red flags  
    R << "RED_FLAGS_COUNT=" << d.red_flags.size() << "\n";

    // Subconscious
    R << "SUBCONSCIOUS_COUNT=" << d.subconscious_acceptances.size() << "\n";
    for (auto& s : d.subconscious_acceptances)
        R << "SUBCONSCIOUS=" << s << "\n";

    // Text descriptions
    R << "ATTACHMENT_DESC=" << getAttachmentDesc(d) << "\n";
    R << "ATTRACTION_DESC=" << getAttractionDesc(d) << "\n";
    R << "AWARENESS_LABEL=" << getSelfAwarenessLabel(awareness) << "\n";

    // Gap analysis
    bool gapExists = d.predicted_type.find("Secure") != string::npos && actualType.find("Secure") == string::npos;
    if (gapExists) {
        R << "GAP_DESC=You see yourself as emotionally secure, but your behavioral responses tell a different story. This gap — between who you believe you are and how you actually respond under pressure — is the most important thing revealed by this quiz. Awareness is the first step.\n";
    } else if (!d.subconscious_acceptances.empty()) {
        R << "GAP_DESC=While your conscious preferences align with your type, your behavioral data reveals traits you claim to reject but actually tolerate or even seek out. This unconscious contradiction is worth examining carefully.\n";
    } else {
        R << "GAP_DESC=Your self-perception and behavioral patterns are largely consistent. You have a reasonably clear picture of who you are attracted to and why. Your work is less about discovery and more about intentional choice.\n";
    }

    // Pattern insight
    if (d.repeats_patterns) {
        R << "PATTERN_DESC=Your relationship history shows a clear repeating pattern. The type of partner you end up with follows a recognizable template — and it may not be the template you consciously choose. Patterns this consistent are rarely accidents. They are the echoes of something deeper.\n";
    } else {
        R << "PATTERN_DESC=Your relationship history does not show a strongly fixed pattern. You have some flexibility in who you attract and are attracted to. This openness is a strength, though it can also mean you haven't yet identified what you truly need.\n";
    }

    // Core wound insight
    if (d.anxious_score > 55) {
        R << "CORE_WOUND=Your data suggests an underlying fear of abandonment. This wound tends to make love feel urgent, electric, and anxious all at once. The antidote isn't finding a \"better\" partner — it's learning to self-soothe and trust that love doesn't have to be earned through constant vigilance.\n";
    } else if (d.avoidant_score > 55) {
        R << "CORE_WOUND=Your data suggests an underlying fear of engulfment — of being consumed, controlled, or losing yourself in love. You protect yourself through distance. The growth edge isn't opening up all at once; it's learning that closeness doesn't mean losing yourself.\n";
    } else if (d.validation_score > 60) {
        R << "CORE_WOUND=Your data suggests a deep need for external validation. Your self-worth may feel unstable without a partner's affirmation. True security begins when you stop outsourcing your value to other people's opinions of you.\n";
    } else {
        R << "CORE_WOUND=Your data does not reveal a dominant core wound in the typical categories. You show a relatively integrated sense of self in relationships. Your challenge may be less about healing and more about intentional deepening of connection.\n";
    }

    R << "===REPORT_END===\n";
    return R.str();
}

// ─── Main ────────────────────────────────────────────────────────────────────

int main() {
    string input, line;
    while (getline(cin, line)) {
        input += line + "\n";
    }

    QuizData data = parseInput(input);
    computeScores(data);
    string report = generateReport(data);
    cout << report;
    return 0;
}